#!/bin/sh
set -eu
PATH=/usr/bin:/bin:/usr/sbin:/sbin:/rootfs/usr/bin:/rootfs/bin:/rootfs/usr/sbin:/rootfs/sbin
export PATH
echo 'KIDS BRIDGE 0.9.6: read-only runtime check'
dpkg-query -W -f='${Package} ${Version}\n' vn.sonnguyen.kids.bridge-kit
for service in kidsdaemon KidsInfoHelper; do
 echo "SERVICE $service"
 launchctl print "system/$service" | sed -n '/state =/p;/pid =/p;/runs =/p;/last exit/p'
done
curl --noproxy '*' -sS --connect-timeout 2 --max-time 5 -o /dev/null -w 'LICENSE HTTP=%{http_code}\n' http://127.0.0.1:16688/license
if [ -f /kids.MobileTemp/com.kids.DeviceInfor.plist ]; then
 echo 'PROFILE FILE: present (content not printed)'
else
 echo 'PROFILE FILE: missing'
fi
echo 'Browser: open SERVER/diagnostics/browser in Safari and Chrome; save separate JSON files.'
