#!/bin/sh
set -eu
PATH=/usr/bin:/bin:/usr/sbin:/sbin:/rootfs/usr/bin:/rootfs/bin:/rootfs/usr/sbin:/rootfs/sbin
export PATH
command -v jbroot >/dev/null || { echo 'This repack requires RootHide';exit 1; }
assets=/usr/share/kids-repacked/com.iosapp.kidschanger
root=$(jbroot);root=${root%/}
case "$root" in /var/containers/Bundle/Application/.jbroot-*|/private/var/containers/Bundle/Application/.jbroot-*) :;; *) echo 'Unexpected RootHide root';exit 1;; esac
stage=$(mktemp -d /tmp/kids-repack.XXXXXX)
trap 'rm -rf "$stage"' EXIT
dd if=/usr/bin/JetsamCTL of="$stage/brand" bs=1 skip=16584 count=8 2>/dev/null
[ "$(wc -c < "$stage/brand" | tr -d ' ')" = 8 ]
while IFS='|' read -r target offsets;do
 [ -n "$target" ] || continue
 source="$target"
 [ ! -f "$target.kids-v4-original" ] || source="$target.kids-v4-original"
 ldid -e "$source" | sed -n '1,/<\/plist>/p' > "$stage/entitlements"
 grep -q '</plist>' "$stage/entitlements"
 identity=$(ldid -h "$source" 2>&1 | sed -n 's/^Identifier=//p' | head -n 1)
 [ -n "$identity" ]
 for offset in $offsets;do dd if="$stage/brand" of="$source" bs=1 seek="$offset" count=8 conv=notrunc 2>/dev/null;done
 ldid "-I$identity" -Hsha1 -Hsha256 "-S$stage/entitlements" "$source"
 jbctl trustcache add "$root$source"
done < "$assets/brands.txt"
while IFS= read -r name;do
 [ -n "$name" ] || continue
 sed "s|@JBROOT@|$root|g" "$assets/launchd/$name" > "/Library/LaunchDaemons/$name"
 chown root:wheel "/Library/LaunchDaemons/$name";chmod 644 "/Library/LaunchDaemons/$name"
done < "$assets/launchd.txt"
