#!/bin/sh
set -eu
cd "$(dirname "$0")"
check_blocks() {
  first=$1; second=$2; start=$3; count=$4; stem=$5
  dd if="$first" of="$stem.before" bs=4096 skip="$start" count="$count" 2>/dev/null
  dd if="$second" of="$stem.after" bs=4096 skip="$start" count="$count" 2>/dev/null
  cmp "$stem.before" "$stem.after" >/dev/null
  rm -f "$stem.before" "$stem.after"
}
command -v ldid >/dev/null
for name in kidsdaemon KidsInfoHelper; do
  test -f "/usr/bin/$name"
  if [ "$name" = kidsdaemon ]; then
    check_blocks "$name.baseline" "/usr/bin/$name" 8 229 "$name.live0"
    check_blocks "$name.baseline" "/usr/bin/$name" 452 243 "$name.live1"
    identifier=kidsdaemon
  else
    check_blocks "$name.baseline" "/usr/bin/$name" 8 60 "$name.live0"
    check_blocks "$name.baseline" "/usr/bin/$name" 144 64 "$name.live1"
    identifier=KidsInfoHelper.0e9d0b3a.unsigned
  fi
  cp "$name.bridge-draft" "$name.signed"
  # Preserve the current RootHide brand in the ARM64 Mach-O header.
  dd if="/usr/bin/$name" of="$name.brand" bs=1 skip=16584 count=8 2>/dev/null
  test "$(wc -c < "$name.brand" | tr -d ' ')" = 8
  dd if="$name.brand" of="$name.signed" bs=1 seek=16584 count=8 conv=notrunc 2>/dev/null
  ldid -e "/usr/bin/$name" | sed -n '1,/<\/plist>/p' > "$name.entitlements"
  grep -q '</plist>' "$name.entitlements"
  chmod 755 "$name.signed"
  ldid -I"$identifier" -Hsha1 -Hsha256 -S"$name.entitlements" "$name.signed"
  if [ "$name" = kidsdaemon ]; then
    check_blocks "$name.bridge-draft" "$name.signed" 8 229 "$name.signed0"
    check_blocks "$name.bridge-draft" "$name.signed" 452 243 "$name.signed1"
  else
    check_blocks "$name.bridge-draft" "$name.signed" 8 60 "$name.signed0"
    check_blocks "$name.bridge-draft" "$name.signed" 144 64 "$name.signed1"
  fi
  echo "PASS: $name baseline code matched; current RootHide brand preserved; signed code unchanged."
done
