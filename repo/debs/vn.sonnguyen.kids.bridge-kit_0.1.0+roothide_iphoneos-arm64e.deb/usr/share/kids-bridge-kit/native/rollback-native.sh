#!/bin/sh
set -eu
backup=$1
# Only one rollback process may restore this test.
mkdir "$backup/restore-lock" 2>/dev/null || exit 0
launchctl bootout system/kidsdaemon 2>/dev/null || true
launchctl bootout system/KidsInfoHelper 2>/dev/null || true
for name in kidsdaemon KidsInfoHelper; do
  cp -p "$backup/$name.original" "/usr/bin/$name.native-restore"
  mv -f "/usr/bin/$name.native-restore" "/usr/bin/$name"
done
while IFS='|' read -r state path; do
  if [ "$state" = present ]; then cp -p "$backup/files/$path" "$path"; else rm -f "$path"; fi
done < "$backup/files.list"
for label in KidsInfoHelper kidsdaemon; do
  if [ -f "$backup/$label.was-running" ]; then
    launchctl enable "system/$label" || true
    if [ "$label" = KidsInfoHelper ]; then plist=/Library/LaunchDaemons/com.kids.KidsInfoHelper.plist
    else plist=/Library/LaunchDaemons/com.kidsautopro.kidsdaemon.plist; fi
    launchctl bootstrap system "$plist" || true
  else
    if [ -f "$backup/$label.was-disabled" ]; then launchctl disable "system/$label" || true; fi
  fi
done
rm -f /tmp/kids-native-probe/pc-native-token /tmp/kids-native-probe/device.pc-secret
echo 'ROLLBACK OK: previous native binaries and activation files restored; UI fix unchanged.'
