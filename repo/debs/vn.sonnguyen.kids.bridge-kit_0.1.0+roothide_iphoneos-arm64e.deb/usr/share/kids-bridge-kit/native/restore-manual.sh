#!/bin/sh
set -eu
B=$(cat /kids.MobileTemp/native-manual-backup-path)
case "$B" in /kids.MobileTemp/native-manual-*) ;; *) echo 'Invalid backup path'; exit 1;; esac
sh "$B/rollback-native.sh" "$B"
