#!/bin/sh
set -eu
cd "$(dirname "$0")"
test "$(id -u)" = 0
expected=$(cat expected-serial.txt)
serial=$(/rootfs/usr/sbin/ioreg -l | sed -n 's/.*"IOPlatformSerialNumber" = "\([^"]*\)".*/\1/p' | head -n 1)
if [ "$serial" != "$expected" ]; then echo 'STOP: device serial does not match this test package.'; exit 1; fi
command -v curl >/dev/null
command -v /usr/bin/jbctl >/dev/null
for path in /Library/LaunchDaemons/com.kids.KidsInfoHelper.plist /Library/LaunchDaemons/com.kidsautopro.kidsdaemon.plist; do test -f "$path"; done
helper_program=$(launchctl print system/KidsInfoHelper | sed -n 's/^[[:space:]]*program = //p' | head -n 1)
case "$helper_program" in /var/containers/Bundle/Application/.jbroot-*/usr/bin/KidsInfoHelper) :;; *) echo 'STOP: unexpected helper program path.'; exit 1;; esac
physical_root=${helper_program%/usr/bin/KidsInfoHelper}
test "$(wc -c < device.pc-secret | tr -d ' ')" = 64
test "$(wc -c < pc-native-token | tr -d ' ')" = 50
curl --noproxy '*' -fsS --connect-timeout 3 --max-time 5 http://192.168.10.13:8787/health -o health.json
grep -q '"version":3' health.json
# Ensure the tested UI fix remains installed before touching services.
ui_code=$(od -An -tx1 -j 196456 -N4 /Library/MobileSubstrate/DynamicLibraries/KidsTweakHelper.dylib | tr -d ' \n')
[ "$ui_code" = c0035fd6 ] || { echo 'STOP: tested block UI fix not found. Nothing installed.'; exit 1; }
# Complete signing and code checks before touching active services.
sh ./sign-native.sh
backup="/kids.MobileTemp/native-manual-$$"
umask 077
mkdir -p "$backup/files"
cp -p /usr/bin/kidsdaemon "$backup/kidsdaemon.original"
cp -p /usr/bin/KidsInfoHelper "$backup/KidsInfoHelper.original"
for label in KidsInfoHelper kidsdaemon; do
  if launchctl print "system/$label" >/dev/null 2>&1; then touch "$backup/$label.was-running"; fi
  if launchctl print-disabled system | grep -q "\"$label\" => true"; then touch "$backup/$label.was-disabled"; fi
done
: > "$backup/files.list"
for path in /kids.MobileTemp/Kids_Authenticate.plist /kids.MobileTemp/LicenseKey /kids.MobileTemp/kids91_pub.der /kids.MobileTemp/com.kidsautopro.activeurl.plist /kids.MobileTemp/pc-session-token /usr/bin/kidsdaemon.pc-secret /usr/bin/KidsInfoHelper.pc-secret /kids.MobileTemp/nt-d-start /kids.MobileTemp/nt-d-auth /kids.MobileTemp/nt-d-key /kids.MobileTemp/nt-h-start /kids.MobileTemp/nt-h-key /kids.MobileTemp/nt-h-http /kids.MobileTemp/nt-d-open-ok /kids.MobileTemp/nt-d-open-fail /kids.MobileTemp/nt-d-read-ok /kids.MobileTemp/nt-d-read-fail; do
  if [ -e "$path" ]; then
    mkdir -p "$backup/files/$(dirname "$path")"
    cp -p "$path" "$backup/files/$path"
    printf 'present|%s\n' "$path" >> "$backup/files.list"
  else printf 'absent|%s\n' "$path" >> "$backup/files.list"; fi
done
cp ./rollback-native.sh "$backup/rollback-native.sh"
chmod 700 "$backup/rollback-native.sh"
echo "Manual rollback mode. Backup: $backup"
trace_stages() {
  echo '=== NATIVE STAGES ==='
  for stage in d-start d-auth d-key h-start h-key h-http d-open-ok d-open-fail d-read-ok d-read-fail; do
    if [ -f "/kids.MobileTemp/nt-$stage" ] && [ ! -s "/kids.MobileTemp/nt-$stage" ]; then
      echo "STAGE $stage: OBSERVED"
    else echo "STAGE $stage: NOT OBSERVED"; fi
  done
}
trap 'code=$?; if [ "$code" -ne 0 ]; then trace_stages; sh "$backup/rollback-native.sh" "$backup" >> "$backup/rollback.log" 2>&1 || true; fi' EXIT HUP INT TERM
# Precreate nonempty controls. Native open uses O_TRUNC without O_CREAT.
for marker in /kids.MobileTemp/nt-d-start /kids.MobileTemp/nt-d-auth /kids.MobileTemp/nt-d-key /kids.MobileTemp/nt-h-start /kids.MobileTemp/nt-h-key /kids.MobileTemp/nt-h-http /kids.MobileTemp/nt-d-open-ok /kids.MobileTemp/nt-d-open-fail /kids.MobileTemp/nt-d-read-ok /kids.MobileTemp/nt-d-read-fail; do
  printf '?' > "$marker"
  chmod 600 "$marker"
done
launchctl bootout system/kidsdaemon 2>/dev/null || true
launchctl bootout system/KidsInfoHelper 2>/dev/null || true
rm -f /kids.MobileTemp/Kids_Authenticate.plist /kids.MobileTemp/LicenseKey
cp kids91_pub.der /kids.MobileTemp/kids91_pub.der
cp pc-native-token /kids.MobileTemp/pc-session-token
cp device.pc-secret /usr/bin/kidsdaemon.pc-secret
cp device.pc-secret /usr/bin/KidsInfoHelper.pc-secret
chmod 600 /kids.MobileTemp/pc-session-token /usr/bin/kidsdaemon.pc-secret /usr/bin/KidsInfoHelper.pc-secret
for name in kidsdaemon KidsInfoHelper; do
  cp "$name.signed" "/usr/bin/$name.native-new"
  chown root:wheel "/usr/bin/$name.native-new"
  chmod 755 "/usr/bin/$name.native-new"
  mv -f "/usr/bin/$name.native-new" "/usr/bin/$name"
done
chown root:wheel /usr/bin/kidsdaemon /usr/bin/KidsInfoHelper
chmod 755 /usr/bin/kidsdaemon /usr/bin/KidsInfoHelper
/usr/bin/jbctl trustcache add "$physical_root/usr/bin/kidsdaemon"
/usr/bin/jbctl trustcache add "$physical_root/usr/bin/KidsInfoHelper"
launchctl enable system/KidsInfoHelper
launchctl enable system/kidsdaemon
launchctl bootstrap system /Library/LaunchDaemons/com.kids.KidsInfoHelper.plist
launchctl bootstrap system /Library/LaunchDaemons/com.kidsautopro.kidsdaemon.plist
ready=no
for attempt in 1 2 3 4 5; do
  if curl --noproxy '*' -sS --connect-timeout 1 --max-time 2 -o /dev/null http://127.0.0.1:16688/license; then ready=yes; break; fi
  sleep 1
done
test "$ready" = yes
helper_pid=$(launchctl print system/KidsInfoHelper | sed -n 's/^[[:space:]]*pid = //p' | head -n 1)
test -n "$helper_pid"
sleep 3
helper_pid_after=$(launchctl print system/KidsInfoHelper | sed -n 's/^[[:space:]]*pid = //p' | head -n 1)
if [ "$helper_pid" != "$helper_pid_after" ]; then
  echo 'STOP: KidsInfoHelper restarted during startup; immediate rollback.'
  exit 1
fi
echo "PASS: helper PID=$helper_pid remained stable; localhost HTTP ready."
if [ ! -f /kids.MobileTemp/nt-d-start ] || [ -s /kids.MobileTemp/nt-d-start ] || [ ! -f /kids.MobileTemp/nt-h-start ] || [ -s /kids.MobileTemp/nt-h-start ]; then
  echo 'STOP: native startup marker control failed; login was NOT retried.'
  exit 1
fi
echo 'PASS: both native startup marker controls observed.'
user=$(cat pc-native-user.txt)
curl --noproxy '*' -sS --connect-timeout 3 --max-time 25 --get --data-urlencode "user=$user" -o "$backup/login-result.json" -w 'Native login HTTP=%{http_code} TIME=%{time_total}s\n' http://127.0.0.1:16688/login
sed -n 's/.*"status"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/Native STATUS=\1/p' "$backup/login-result.json"
trace_stages
if ! grep -q '"status"[[:space:]]*:[[:space:]]*"success"' "$backup/login-result.json"; then
  echo 'STOP: native login was not successful; restoring previous state.'
  exit 1
fi
printf '%s\n' "$backup" > /kids.MobileTemp/native-manual-backup-path
for name in Kids_Authenticate.plist LicenseKey; do
  test -s "/kids.MobileTemp/$name"
done
echo 'INSTALLED: native login succeeded; two daemons and native session remain installed.'
echo 'Block UI tweak unchanged. No automatic rollback. Do not run old probes.'
