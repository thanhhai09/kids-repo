#!/bin/sh
set -eu
APP=/Applications/iOSKidsChanger.app/iOSKidsChanger
BACKUP=/kids.MobileTemp/pc-login-test-backup/iOSKidsChanger.before-refresh
test -f "$BACKUP"
killall iOSKidsChanger 2>/dev/null || true
sudo cp -p "$BACKUP" "$APP"
echo 'Previous working PC-login binary restored.'
