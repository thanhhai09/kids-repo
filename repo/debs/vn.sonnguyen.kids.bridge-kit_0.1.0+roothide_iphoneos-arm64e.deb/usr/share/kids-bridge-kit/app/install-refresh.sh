#!/bin/sh
set -eu
cd "$(dirname "$0")"
APP=/Applications/iOSKidsChanger.app/iOSKidsChanger
BACKUP=/kids.MobileTemp/pc-login-test-backup
test -f "$APP"
test -f "$BACKUP/iOSKidsChanger.original"
command -v ldid >/dev/null
command -v jbctl >/dev/null
cp iOSKidsChanger.pc-refresh iOSKidsChanger.refresh-signed
chmod 755 iOSKidsChanger.refresh-signed
ldid -IiOSKidsChanger.bb3f463d.unsigned -Hsha1 -Hsha256 -Sentitlements.plist iOSKidsChanger.refresh-signed
ldid -e iOSKidsChanger.refresh-signed > refresh-entitlements.plist
cat entitlements.plist entitlements.plist > refresh-expected-entitlements.plist
cmp refresh-expected-entitlements.plist refresh-entitlements.plist
physical_dir=$(pwd -P)
case "$physical_dir" in
  /rootfs/*) physical_dir=${physical_dir#/rootfs} ;;
esac
sudo jbctl trustcache add "$physical_dir/iOSKidsChanger.refresh-signed"
if [ ! -f "$BACKUP/iOSKidsChanger.before-refresh" ]; then
  sudo cp -p "$APP" "$BACKUP/iOSKidsChanger.before-refresh"
fi
killall iOSKidsChanger 2>/dev/null || true
sudo cp iOSKidsChanger.refresh-signed "$APP"
sudo chown root:wheel "$APP"
sudo chmod 755 "$APP"
echo 'PC login + refresh test installed. Activation/license routes unchanged.'
