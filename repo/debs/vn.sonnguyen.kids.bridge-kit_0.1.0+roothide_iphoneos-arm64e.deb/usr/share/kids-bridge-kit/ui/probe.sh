#!/bin/sh
set -eu
cd /tmp/kids-no-block-probe
[ "$(id -u)" = 0 ] || { echo 'Run with sudo.'; exit 1; }
D=/Library/MobileSubstrate/DynamicLibraries
PROGRAM=$(launchctl print system/KidsInfoHelper | sed -n 's/^[[:space:]]*program = //p' | head -n 1)
case "$PROGRAM" in
  /var/containers/Bundle/Application/.jbroot-*/usr/bin/KidsInfoHelper) JBROOT=${PROGRAM%/usr/bin/KidsInfoHelper} ;;
  /private/var/containers/Bundle/Application/.jbroot-*/usr/bin/KidsInfoHelper) JBROOT=${PROGRAM%/usr/bin/KidsInfoHelper} ;;
  *) echo 'Cannot determine current RootHide root. Nothing installed.'; exit 1 ;;
esac
for N in KidsTweakHelper; do
  cmp "$D/$N.dylib" "/rootfs$JBROOT/Library/MobileSubstrate/DynamicLibraries/$N.dylib" || { echo 'RootHide path mismatch. Nothing installed.'; exit 1; }
done
BACKUP=/kids.MobileTemp/no-block-ui-probe-$$
mkdir -p "$BACKUP"
chmod 700 "$BACKUP"
N=KidsTweakHelper
[ -f "$D/$N.dylib" ] || { echo "Missing $N.dylib. Stop; do not rename disabled files blindly."; exit 1; }
dd if="$D/$N.dylib" of="$N.current.text" bs=1 skip=32768 count=232816 2>/dev/null
dd if="$N.baseline" of="$N.baseline.text" bs=1 skip=32768 count=232816 2>/dev/null
cmp "$N.current.text" "$N.baseline.text" || { echo "Live code differs: $N"; exit 1; }
cp "$N.draft" "$N.signed"
dd if="$D/$N.dylib" of="$N.brand" bs=1 skip=16584 count=8 2>/dev/null
dd if="$N.brand" of="$N.signed" bs=1 seek=16584 count=8 conv=notrunc 2>/dev/null
ldid -e "$D/$N.dylib" | sed -n '1,/<\/plist>/p' > "$N.entitlements"
grep -q '</plist>' "$N.entitlements"
SIGN_ID=$(ldid -h "$D/$N.dylib" 2>&1 | sed -n 's/^Identifier=//p' | head -n 1)
[ -n "$SIGN_ID" ]
ldid -I"$SIGN_ID" -Hsha1 -Hsha256 -S"$N.entitlements" "$N.signed"
dd if="$N.draft" of="$N.draft.text" bs=1 skip=32768 count=232816 2>/dev/null
dd if="$N.signed" of="$N.signed.text" bs=1 skip=32768 count=232816 2>/dev/null
cmp "$N.draft.text" "$N.signed.text"
cp -p "$D/$N.dylib" "$BACKUP/$N.original"
echo "PASS: $N live code matched; signed code unchanged."
cp rollback.sh "$BACKUP/rollback.sh"
trap 'rc=$?; if [ "$rc" -ne 0 ]; then sh "$BACKUP/rollback.sh" "$BACKUP" now; fi' EXIT
for N in KidsTweakHelper; do
  TARGET="$D/$N.dylib"
  cp "$N.signed" "$TARGET.no-block-stage"
  chown root:wheel "$TARGET.no-block-stage"
  chmod 755 "$TARGET.no-block-stage"
  mv -f "$TARGET.no-block-stage" "$TARGET"
  /usr/bin/jbctl trustcache add "$JBROOT/Library/MobileSubstrate/DynamicLibraries/$N.dylib"
done
echo "INSTALLED: manual rollback mode; test files remain installed."
echo "Backup: $BACKUP"
printf '%s\n' "$BACKUP" > /kids.MobileTemp/no-block-manual-backup-path
echo 'No automatic rollback. Enable Load Tweaks after installation to test.'
killall SpringBoard || true
