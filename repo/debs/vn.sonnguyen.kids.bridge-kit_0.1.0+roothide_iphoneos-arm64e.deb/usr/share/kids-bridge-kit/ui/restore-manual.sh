#!/bin/sh
set -eu
B=$(cat /kids.MobileTemp/no-block-manual-backup-path)
case "$B" in /kids.MobileTemp/no-block-ui-probe-*) ;; *) echo 'Invalid backup path'; exit 1;; esac
sh "$B/rollback.sh" "$B" now
