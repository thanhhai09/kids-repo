#!/bin/sh
set -eu
B=$1
if [ "${2:-now}" = wait ]; then
  echo 'WATCHDOG waiting 90 seconds'
  touch "$B/watchdog.ready"
  sleep 90
fi
mkdir "$B/restore-lock" 2>/dev/null || exit 0
D=/Library/MobileSubstrate/DynamicLibraries
for N in KidsTweakHelper; do
  cp -p "$B/$N.original" "$D/$N.dylib.restore-stage"
  mv -f "$D/$N.dylib.restore-stage" "$D/$N.dylib"
done
echo 'ROLLBACK OK: original KidsTweakHelper restored.'
killall SpringBoard || true
