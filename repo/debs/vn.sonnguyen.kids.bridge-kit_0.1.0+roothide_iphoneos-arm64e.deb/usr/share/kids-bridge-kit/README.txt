Staged tested payloads only. Installing this DEB does not activate or modify live binaries.
Use the supplied PC/manual kits after configuring the new device IP and serial.
Only ARM64 on iPhone 6s / iOS 15.8.8 has been verified; ARM64e slices retain original behavior.
Keep Load Tweaks OFF while installing originals and until applying the UI fix.
Do not run probe.sh directly from this directory: copy its directory to the documented private tmp location.
