#!/bin/sh
# Enroll only through the signed, administrator-approved server workflow.
set -eu
PATH=/usr/bin:/bin:/usr/sbin:/sbin:/rootfs/usr/bin:/rootfs/bin:/rootfs/usr/sbin:/rootfs/sbin
export PATH
umask 077
assets=/usr/share/kids-roothide-v4
state=/kids.MobileTemp/kids-roothide-v4-state
work=$state/enrollment
publicdir=/rootfs/var/mobile/Library/KidsAutoEnrollment
server=https://autochangeinfor.new.tg
fallback=https://autochangeinfor-gateway.onrender.com
pinned=827250948be5dbf207621ae009fde8947bcb85e07a993d79719f92e4d9935cf0
mkdir -p "$work" "$publicdir"
chmod 700 "$work"
chmod 755 "$publicdir"
status() {
 printf '%s\n' "$1" > "$publicdir/status.new"
 chmod 644 "$publicdir/status.new"
 mv -f "$publicdir/status.new" "$publicdir/status"
}
# Serialize launchd and install-time runs. Recover a lock after a killed worker.
lock=$work/worker.lock
if ! mkdir "$lock" 2>/dev/null;then
 pid=$(cat "$lock/pid" 2>/dev/null || true)
 if [ -z "$pid" ];then
  # A previous process may have died between mkdir and writing its PID.
  # Give a concurrent creator time to publish its PID, then reclaim only
  # an empty directory. Never delete another worker's published lock.
  sleep 1
  rmdir "$lock" 2>/dev/null || exit 0
 else
  case "$pid" in *[!0-9]*) exit 0;; esac
  kill -0 "$pid" 2>/dev/null && exit 0
  rm -f "$lock/pid";rmdir "$lock" 2>/dev/null || exit 0
 fi
 mkdir "$lock" 2>/dev/null || exit 0
fi
echo $$ > "$lock/pid"
cleanup() { rc=$?;rm -f "$lock/pid";rmdir "$lock" 2>/dev/null || true;if [ "$rc" -ne 0 ];then status error;fi; }
trap cleanup EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
if [ -f "$state/configured" ] && [ -s /kids.MobileTemp/kids91_pub.der ] &&
 [ "$(wc -c < /usr/bin/kidsdaemon.pc-secret 2>/dev/null || true)" -eq 64 ] 2>/dev/null &&
 [ "$(wc -c < /usr/bin/KidsInfoHelper.pc-secret 2>/dev/null || true)" -eq 64 ] 2>/dev/null;then
 status ready;exit 0
fi
# A stale marker must not suppress enrollment after a partial reinstall.
rm -f "$state/configured"
status configuring
request() {
 route=$1;body=$2
 for base in "$server" "$fallback";do
  if curl --noproxy '*' -fsS --connect-timeout 5 --max-time 20 -H 'Content-Type: application/json' --data-binary "@$body" "$base$route" -o "$work/reply.new";then
   mv -f "$work/reply.new" "$work/reply.json";return 0
  fi
 done
 rm -f "$work/reply.new";status offline;return 1
}
if [ ! -s "$work/private.pem" ];then
 openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 -out "$work/private.pem.new" 2>/dev/null
 mv "$work/private.pem.new" "$work/private.pem"
fi
openssl pkey -in "$work/private.pem" -pubout -outform DER -out "$work/public.der" 2>/dev/null
if [ ! -s "$work/id" ];then openssl rand -hex 16 > "$work/id";fi
if [ ! -s "$work/token" ];then openssl rand -hex 32 > "$work/token";fi
id=$(cat "$work/id");token=$(cat "$work/token")
serial=$(/rootfs/usr/sbin/ioreg -rd1 -c IOPlatformExpertDevice | sed -n 's/.*"IOPlatformSerialNumber" = "\([A-Z0-9]*\)".*/\1/p' | head -n 1)
case "$serial" in ''|*[!A-Z0-9]*) echo 'Cannot read real serial';exit 1;; esac
public=$(openssl base64 -A -in "$work/public.der")
fingerprint=$(sha256sum "$work/public.der" | cut -c1-16)
printf 'Serial: %s\nKey: %s\nApprove this iPhone at %s/admin\n' "$serial" "$fingerprint" "$server" > "$work/status.txt"
printf '{"id":"%s","token":"%s","serial":"%s","public_key":"%s"}' "$id" "$token" "$serial" "$public" > "$work/register.json"
printf '{"id":"%s","token":"%s"}' "$id" "$token" > "$work/poll.json"
request /api/enrollment/register "$work/register.json" || exit 0
request /api/enrollment/status "$work/poll.json" || exit 0
if grep -Eq '"status"[[:space:]]*:[[:space:]]*"pending"' "$work/reply.json";then status pending;exit 0;fi
grep -Eq '"status"[[:space:]]*:[[:space:]]*"approved"' "$work/reply.json" || { status error;exit 0; }
status configuring
for field in sealed signature public;do
 sed -n "s/.*\"$field\"[[:space:]]*:[[:space:]]*\"\([A-Za-z0-9+\/=]*\)\".*/\1/p" "$work/reply.json" | openssl base64 -d -A > "$work/$field.bin"
 test -s "$work/$field.bin"
done
actual=$(sha256sum "$work/public.bin" | cut -d ' ' -f 1)
[ "$actual" = "$pinned" ] || { echo 'Server public key mismatch';exit 1; }
openssl pkey -pubin -inform DER -in "$work/public.bin" -out "$work/server.pem" 2>/dev/null
openssl dgst -sha256 -verify "$work/server.pem" -signature "$work/signature.bin" "$work/sealed.bin" >/dev/null
input=/var/mobile/kids-roothide-config-$id
mkdir -p "$input";chmod 700 "$input"
openssl pkeyutl -decrypt -inkey "$work/private.pem" -in "$work/sealed.bin" -out "$input/material.bin" -pkeyopt rsa_padding_mode:oaep -pkeyopt rsa_oaep_md:sha256 -pkeyopt rsa_mgf1_md:sha256
cp "$work/public.bin" "$input/public.der"
sh "$assets/provision.sh" "$input"
request /api/enrollment/complete "$work/poll.json" || true
rm -f "$work/register.json" "$work/poll.json" "$work/reply.json" "$work/private.pem" "$work/token" "$work/sealed.bin" "$work/signature.bin"
status ready
echo 'Configured. Open Kids and verify the device using the existing account.' > "$work/status.txt"
