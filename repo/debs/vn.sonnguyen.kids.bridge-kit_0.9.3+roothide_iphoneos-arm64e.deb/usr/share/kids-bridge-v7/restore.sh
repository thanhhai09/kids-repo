#!/bin/sh
set -eu
PATH=/usr/bin:/bin:/usr/sbin:/sbin:/rootfs/usr/bin:/rootfs/bin:/rootfs/usr/sbin:/rootfs/sbin
export PATH
pkg=vn.sonnguyen.kids.bridge-kit
backup=/kids.MobileTemp/kids-bridge-original-state
launchctl bootout system/kidsdaemon 2>/dev/null || true
launchctl bootout system/KidsInfoHelper 2>/dev/null || true
# Literal destinations also work in postrm after package assets have been removed.
for target in /Applications/iOSKidsChanger.app/iOSKidsChanger /usr/bin/KidsInfoHelper /usr/bin/kidsdaemon /Library/MobileSubstrate/DynamicLibraries/Kids_DeviceProof.dylib /Library/MobileSubstrate/DynamicLibraries/KidsTweakHelper.dylib; do
 if [ "$(dpkg-divert --listpackage "$target")" = "$pkg" ]; then
  rm -f "$target"
  dpkg-divert --package "$pkg" --remove --rename --divert "$target.kids-original" "$target"
 fi
done
if [ -f "$backup/saved" ]; then
 for path in /kids.MobileTemp/kids91_pub.der /usr/bin/kidsdaemon.pc-secret /usr/bin/KidsInfoHelper.pc-secret; do
  name=$(basename "$path")
  if [ -f "$backup/$name.absent" ]; then rm -f "$path";
  elif [ -f "$backup/$name" ]; then
   cat "$backup/$name" > "$path.kids-restore";chown root:wheel "$path.kids-restore";chmod 600 "$path.kids-restore";mv -f "$path.kids-restore" "$path"
  fi
 done
fi
for service in KidsInfoHelper kidsdaemon; do launchctl enable "system/$service";done
launchctl bootstrap system /Library/LaunchDaemons/com.kids.KidsInfoHelper.plist 2>/dev/null || true
launchctl bootstrap system /Library/LaunchDaemons/com.kidsautopro.kidsdaemon.plist 2>/dev/null || true
echo 'RESTORED: original binaries and previous public key/material; licence files untouched'
