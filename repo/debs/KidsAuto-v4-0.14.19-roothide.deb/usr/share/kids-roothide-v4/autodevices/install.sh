#!/bin/sh
set -eu
PATH=/usr/bin:/bin:/usr/sbin:/sbin
export PATH
assets=/usr/share/kids-roothide-v4/autodevices
target=/Library/MobileSubstrate/DynamicLibraries/KidsAutoDevices.dylib
stage=$(mktemp -d /tmp/kids-autodevices.XXXXXX)
trap 'rm -rf "$stage"' EXIT
cp "$assets/KidsAutoDevices.dylib" "$stage/KidsAutoDevices.dylib"
dd if=/usr/bin/JetsamCTL of="$stage/brand" bs=1 skip=16584 count=8 2>/dev/null
[ "$(wc -c < "$stage/brand" | tr -d ' ')" = 8 ]
dd if="$stage/brand" of="$stage/KidsAutoDevices.dylib" bs=1 seek=128 count=8 conv=notrunc 2>/dev/null
ldid -IKidsAutoDevices -Hsha1 -Hsha256 -S "$stage/KidsAutoDevices.dylib"
root=$(jbroot);root=${root%/}
jbctl trustcache add "$root$stage/KidsAutoDevices.dylib"
mkdir -p /Library/MobileSubstrate/DynamicLibraries
cp "$stage/KidsAutoDevices.dylib" "$target.new"
chown root:wheel "$target.new";chmod 644 "$target.new"
mv -f "$target.new" "$target"
cp "$assets/KidsAutoDevices.plist" /Library/MobileSubstrate/DynamicLibraries/KidsAutoDevices.plist
chown root:wheel /Library/MobileSubstrate/DynamicLibraries/KidsAutoDevices.plist
chmod 644 /Library/MobileSubstrate/DynamicLibraries/KidsAutoDevices.plist
touch /kids.MobileTemp/kids-roothide-v4-state/autodevices-owned
