#!/bin/sh
set -eu
assets=/usr/share/kids-roothide-v4/remote
state=/kids.MobileTemp/kids-roothide-v4-state
stage=$(mktemp -d /tmp/kids-remote.XXXXXX)
trap 'rm -rf "$stage"' EXIT
cp "$assets/KidsRemoteEndpoint.dylib" "$stage/remote.dylib"
dd if=/usr/bin/JetsamCTL of="$stage/brand" bs=1 skip=16584 count=8 2>/dev/null
[ "$(wc -c < "$stage/brand" | tr -d ' ')" = 8 ]
dd if="$stage/brand" of="$stage/remote.dylib" bs=1 seek=128 count=8 conv=notrunc 2>/dev/null
ldid -IKidsRemoteEndpoint -Hsha1 -Hsha256 -S "$stage/remote.dylib"
root=$(jbroot);root=${root%/}
jbctl trustcache add "$root$stage/remote.dylib"
mkdir -p /usr/lib/TweakInject
cp "$stage/remote.dylib" /usr/lib/TweakInject/KidsRemoteEndpoint.dylib.new
chmod 644 /usr/lib/TweakInject/KidsRemoteEndpoint.dylib.new
chown root:wheel /usr/lib/TweakInject/KidsRemoteEndpoint.dylib.new
mv -f /usr/lib/TweakInject/KidsRemoteEndpoint.dylib.new /usr/lib/TweakInject/KidsRemoteEndpoint.dylib
cp "$assets/KidsRemoteEndpoint.plist" /usr/lib/TweakInject/KidsRemoteEndpoint.plist
chmod 644 /usr/lib/TweakInject/KidsRemoteEndpoint.plist
chown root:wheel /usr/lib/TweakInject/KidsRemoteEndpoint.plist
touch "$state/remote-owned"
