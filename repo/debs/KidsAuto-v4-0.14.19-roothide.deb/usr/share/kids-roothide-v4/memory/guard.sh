#!/bin/sh
PATH=/usr/bin:/bin:/usr/sbin:/sbin:/rootfs/bin
export PATH
last_pid=
log=/var/mobile/Library/Logs/kids-memory-guard.log
while :; do
    pid=$(launchctl list | awk '$3 == "kidsdaemon" && $1 ~ /^[0-9]+$/ {print $1}')
    if [ -n "$pid" ] && [ "$pid" != "$last_pid" ]; then
        if /usr/libexec/kids-memory/limit "$pid" && /usr/libexec/kids-memory/limit "$pid" verify; then
            last_pid=$pid
            printf '%s pid=%s memory_limit=128MB verified\n' "$(date)" "$pid" >> "$log"
        else
            printf '%s pid=%s memory_limit_apply_failed\n' "$(date)" "$pid" >> "$log"
        fi
    fi
    sleep 2
done
