#!/bin/sh
set -eu
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
assets=/usr/share/kids-roothide-v4
state=/kids.MobileTemp/kids-roothide-v4-state
stage=$(mktemp -d /tmp/kids-latest-fix.XXXXXX)
trap 'rm -rf "$stage"' EXIT
dd if=/usr/bin/JetsamCTL of="$stage/brand" bs=1 skip=16584 count=8 2>/dev/null
[ "$(wc -c < "$stage/brand" | tr -d ' ')" = 8 ]
root=$(jbroot);root=${root%/}
mkdir -p /usr/lib/TweakInject "$state/filter-backups"
cp "$assets/ip-region/KidsIPRegion.dylib" "$stage/KidsIPRegion.dylib"
dd if="$stage/brand" of="$stage/KidsIPRegion.dylib" bs=1 seek=128 count=8 conv=notrunc 2>/dev/null
ldid -IKidsIPRegion -Hsha1 -Hsha256 -S "$stage/KidsIPRegion.dylib"
jbctl trustcache add "$root$stage/KidsIPRegion.dylib"
cat "$stage/KidsIPRegion.dylib" > "/usr/lib/KidsIPRegion.dylib.new"
chmod 644 "/usr/lib/KidsIPRegion.dylib.new"
chown root:wheel "/usr/lib/KidsIPRegion.dylib.new"
mv -f "/usr/lib/KidsIPRegion.dylib.new" "/usr/lib/KidsIPRegion.dylib"
cp "$assets/latest-fixes/KidsIdentifiers.dylib" "$stage/KidsIdentifiers.dylib"
dd if="$stage/brand" of="$stage/KidsIdentifiers.dylib" bs=1 seek=128 count=8 conv=notrunc 2>/dev/null
ldid -IKidsIdentifiers -Hsha1 -Hsha256 -S "$stage/KidsIdentifiers.dylib"
jbctl trustcache add "$root$stage/KidsIdentifiers.dylib"
cat "$stage/KidsIdentifiers.dylib" > "/usr/lib/TweakInject/KidsIdentifiers.dylib.new"
chmod 644 "/usr/lib/TweakInject/KidsIdentifiers.dylib.new"
chown root:wheel "/usr/lib/TweakInject/KidsIdentifiers.dylib.new"
mv -f "/usr/lib/TweakInject/KidsIdentifiers.dylib.new" "/usr/lib/TweakInject/KidsIdentifiers.dylib"
cp "$assets/latest-fixes/KidsFakeClient.dylib" "$stage/KidsFakeClient.dylib"
dd if="$stage/brand" of="$stage/KidsFakeClient.dylib" bs=1 seek=128 count=8 conv=notrunc 2>/dev/null
ldid -IKidsFakeClient -Hsha1 -Hsha256 -S "$stage/KidsFakeClient.dylib"
jbctl trustcache add "$root$stage/KidsFakeClient.dylib"
cat "$stage/KidsFakeClient.dylib" > "/usr/lib/TweakInject/KidsFakeClient.dylib.new"
chmod 644 "/usr/lib/TweakInject/KidsFakeClient.dylib.new"
chown root:wheel "/usr/lib/TweakInject/KidsFakeClient.dylib.new"
mv -f "/usr/lib/TweakInject/KidsFakeClient.dylib.new" "/usr/lib/TweakInject/KidsFakeClient.dylib"
cat "$assets/latest-fixes/KidsIdentifiers.plist" > "/usr/lib/TweakInject/KidsIdentifiers.plist"
chmod 644 "/usr/lib/TweakInject/KidsIdentifiers.plist"
chown root:wheel "/usr/lib/TweakInject/KidsIdentifiers.plist"
cat "$assets/latest-fixes/KidsFakeClient.plist" > "/usr/lib/TweakInject/KidsFakeClient.plist"
chmod 644 "/usr/lib/TweakInject/KidsFakeClient.plist"
chown root:wheel "/usr/lib/TweakInject/KidsFakeClient.plist"
if [ -f "/usr/lib/TweakInject/KidsTweakHelper.plist" ] && [ ! -f "$state/filter-backups/KidsTweakHelper.plist" ];then cp "/usr/lib/TweakInject/KidsTweakHelper.plist" "$state/filter-backups/KidsTweakHelper.plist";fi
cat "$assets/latest-fixes/KidsTweakHelper.plist" > "/usr/lib/TweakInject/KidsTweakHelper.plist"
chmod 644 "/usr/lib/TweakInject/KidsTweakHelper.plist"
chown root:wheel "/usr/lib/TweakInject/KidsTweakHelper.plist"
if [ -f "/usr/lib/TweakInject/Kids_DeviceProof.plist" ] && [ ! -f "$state/filter-backups/Kids_DeviceProof.plist" ];then cp "/usr/lib/TweakInject/Kids_DeviceProof.plist" "$state/filter-backups/Kids_DeviceProof.plist";fi
cat "$assets/latest-fixes/Kids_DeviceProof.plist" > "/usr/lib/TweakInject/Kids_DeviceProof.plist"
chmod 644 "/usr/lib/TweakInject/Kids_DeviceProof.plist"
chown root:wheel "/usr/lib/TweakInject/Kids_DeviceProof.plist"
touch "$state/ip-region-owned" "$state/latest-fixes-owned"
