#!/bin/sh
set -eu
PATH=/usr/bin:/bin:/usr/sbin:/sbin:/rootfs/usr/bin:/rootfs/bin:/rootfs/usr/sbin:/rootfs/sbin
export PATH
for pair in 'KidsInfoHelper com.kids.KidsInfoHelper.plist' 'kidsdaemon com.kidsautopro.kidsdaemon.plist' 'DaemonHelper com.kids.DaemonHelper.plist';do
 set -- $pair
 [ -f "/Library/LaunchDaemons/$2" ] || continue
 launchctl enable "system/$1"
 launchctl bootout "system/$1" 2>/dev/null || true
 launchctl bootstrap system "/Library/LaunchDaemons/$2"
done
ready=no
for attempt in 1 2 3 4 5 6 7 8;do
 if curl --noproxy '*' -fsS --connect-timeout 1 --max-time 2 -o /dev/null http://127.0.0.1:16688/license;then ready=yes;break;fi
 sleep 1
done
[ "$ready" = yes ] || { echo 'Local port 16688 not ready; run THU-KET-QUA.cmd';exit 1; }
echo 'READY: port 16688 responds. Respring, open KidsChanger and log in through the PC backend.'
