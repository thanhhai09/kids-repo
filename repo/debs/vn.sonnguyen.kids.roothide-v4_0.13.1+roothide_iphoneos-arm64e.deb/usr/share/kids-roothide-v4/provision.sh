#!/bin/sh
set -eu
PATH=/usr/bin:/bin:/usr/sbin:/sbin:/rootfs/usr/bin:/rootfs/bin:/rootfs/usr/sbin:/rootfs/sbin
export PATH
[ "$(id -u)" = 0 ]
input=${1:?upload directory required}
case "$input" in /var/mobile/kids-roothide-config-*) :;; *) exit 1;; esac
[ "$(wc -c < "$input/material.bin" | tr -d ' ')" = 64 ]
openssl pkey -pubin -inform DER -in "$input/public.der" -noout >/dev/null
curl --noproxy '*' -fsS --connect-timeout 3 --max-time 8 -o /dev/null http://192.168.10.13:8787/health
state=/kids.MobileTemp/kids-roothide-v4-state
[ -d "$state" ] && [ ! -L "$state" ]
if [ ! -f "$state/config-backup-saved" ];then
 for path in /kids.MobileTemp/kids91_pub.der /usr/bin/KidsInfoHelper.pc-secret /usr/bin/kidsdaemon.pc-secret;do
  name=$(basename "$path")
  if [ -f "$path" ];then cp "$path" "$state/$name.before";else touch "$state/$name.absent";fi
 done
 touch "$state/config-backup-saved"
fi
for service in DaemonHelper kidsdaemon KidsInfoHelper;do launchctl bootout "system/$service" 2>/dev/null || true;done
umask 077
for name in KidsInfoHelper kidsdaemon;do
 target=/usr/bin/$name.pc-secret
 cp "$input/material.bin" "$target.new";chown root:wheel "$target.new";chmod 600 "$target.new";mv -f "$target.new" "$target"
done
key=/kids.MobileTemp/kids91_pub.der
cp "$input/public.der" "$key.new";chown root:wheel "$key.new";chmod 600 "$key.new";mv -f "$key.new" "$key"
touch "$state/configured"
rm -f "$input/material.bin" "$input/public.der";rmdir "$input" 2>/dev/null || true
sh /usr/share/kids-roothide-v4/start.sh
