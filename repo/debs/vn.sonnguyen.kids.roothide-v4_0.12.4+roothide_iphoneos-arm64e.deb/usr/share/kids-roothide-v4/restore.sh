#!/bin/sh
set -eu
PATH=/usr/bin:/bin:/usr/sbin:/sbin:/rootfs/usr/bin:/rootfs/bin:/rootfs/usr/sbin:/rootfs/sbin
export PATH
pkg=vn.sonnguyen.kids.roothide-v4
state=/kids.MobileTemp/kids-roothide-v4-state
for service in DaemonHelper kidsdaemon KidsInfoHelper;do launchctl bootout "system/$service" 2>/dev/null || true;done
for target in /Applications/iOSKidsChanger.app/iOSKidsChanger /usr/bin/KidsInfoHelper /usr/bin/kidsdaemon /Library/MobileSubstrate/DynamicLibraries/Kids_DeviceProof.dylib /usr/lib/TweakInject/Kids_DeviceProof.dylib;do
 if [ "$(dpkg-divert --listpackage "$target")" = "$pkg" ];then
  [ -f "$target.kids-v4-original" ] || { echo "Missing original: $target";exit 1; }
  rm -f "$target"
  dpkg-divert --package "$pkg" --remove --rename --divert "$target.kids-v4-original" "$target"
 fi
done
if [ -f "$state/config-backup-saved" ];then
 for path in /kids.MobileTemp/kids91_pub.der /usr/bin/KidsInfoHelper.pc-secret /usr/bin/kidsdaemon.pc-secret;do
  name=$(basename "$path")
  if [ -f "$state/$name.before" ];then cp "$state/$name.before" "$path";chown root:wheel "$path";chmod 600 "$path";
  elif [ -f "$state/$name.absent" ];then rm -f "$path";fi
 done
fi
if [ -f "$state/extras-created" ] && [ -f /usr/share/kids-roothide-v4/default-extras.plist ];then
 if cmp -s /kids.MobileTemp/com.kids.ExtrasParameters.plist /usr/share/kids-roothide-v4/default-extras.plist;then rm -f /kids.MobileTemp/com.kids.ExtrasParameters.plist;fi
fi
rm -f "$state/configured"
for pair in 'KidsInfoHelper com.kids.KidsInfoHelper.plist' 'kidsdaemon com.kidsautopro.kidsdaemon.plist' 'DaemonHelper com.kids.DaemonHelper.plist';do
 set -- $pair
 [ ! -f "/Library/LaunchDaemons/$2" ] || launchctl bootstrap system "/Library/LaunchDaemons/$2" 2>/dev/null || true
done
echo 'RESTORED: exact original binaries and previous backend key configuration.'
