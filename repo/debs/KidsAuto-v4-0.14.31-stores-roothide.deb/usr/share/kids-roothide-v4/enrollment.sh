#!/bin/sh
# Only the administrator approves bootstrap; this script never grants a serial.
set -eu
PATH=/usr/bin:/bin:/usr/sbin:/sbin:/rootfs/usr/bin:/rootfs/bin:/rootfs/usr/sbin:/rootfs/sbin
export PATH
umask 077
assets=/usr/share/kids-roothide-v4
state=/kids.MobileTemp/kids-roothide-v4-state
work=$state/enrollment
server=https://autochangeinfor.new.tg
pinned=827250948be5dbf207621ae009fde8947bcb85e07a993d79719f92e4d9935cf0
mkdir -p "$work"
chmod 700 "$work"
# A configured device has nothing to enroll. Keep the service idle afterwards.
if [ -f "$state/configured" ];then exit 0;fi
if [ ! -s "$work/private.pem" ];then
 openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 -out "$work/private.pem.new" 2>/dev/null
 mv "$work/private.pem.new" "$work/private.pem"
fi
openssl pkey -in "$work/private.pem" -pubout -outform DER -out "$work/public.der" 2>/dev/null
if [ ! -s "$work/id" ];then openssl rand -hex 16 > "$work/id";fi
if [ ! -s "$work/token" ];then openssl rand -hex 32 > "$work/token";fi
id=$(cat "$work/id");token=$(cat "$work/token")
serial=$(/rootfs/usr/sbin/ioreg -rd1 -c IOPlatformExpertDevice | sed -n 's/.*"IOPlatformSerialNumber" = "\([A-Z0-9]*\)".*/\1/p' | head -n 1)
case "$serial" in ''|*[!A-Z0-9]*) echo 'Cannot read real serial';exit 1;; esac
public=$(openssl base64 -A -in "$work/public.der")
fingerprint=$(sha256sum "$work/public.der" | cut -c1-16)
printf 'Serial: %s\nKey: %s\nApprove this iPhone at %s/admin\n' "$serial" "$fingerprint" "$server" > "$work/status.txt"
printf '{"id":"%s","token":"%s","serial":"%s","public_key":"%s"}' "$id" "$token" "$serial" "$public" > "$work/register.json"
printf '{"id":"%s","token":"%s"}' "$id" "$token" > "$work/poll.json"
curl --noproxy '*' -fsS --connect-timeout 3 --max-time 120 -H 'Content-Type: application/json' --data-binary "@$work/register.json" "$server/api/enrollment/register" -o "$work/reply.json"
curl --noproxy '*' -fsS --connect-timeout 3 --max-time 120 -H 'Content-Type: application/json' --data-binary "@$work/poll.json" "$server/api/enrollment/status" -o "$work/reply.json"
grep -q '"status":"approved"' "$work/reply.json" || exit 0
for field in sealed signature public;do
 sed -n "s/.*\"$field\":\"\([A-Za-z0-9+\/=]*\)\".*/\1/p" "$work/reply.json" | openssl base64 -d -A > "$work/$field.bin"
 test -s "$work/$field.bin"
done
actual=$(sha256sum "$work/public.bin" | cut -d ' ' -f 1)
[ "$actual" = "$pinned" ] || { echo 'Server public key mismatch';exit 1; }
openssl pkey -pubin -inform DER -in "$work/public.bin" -out "$work/server.pem" 2>/dev/null
openssl dgst -sha256 -verify "$work/server.pem" -signature "$work/signature.bin" "$work/sealed.bin" >/dev/null
input=/var/mobile/kids-roothide-config-$id
mkdir -p "$input"
chmod 700 "$input"
openssl pkeyutl -decrypt -inkey "$work/private.pem" -in "$work/sealed.bin" -out "$input/material.bin" -pkeyopt rsa_padding_mode:oaep -pkeyopt rsa_oaep_md:sha256 -pkeyopt rsa_mgf1_md:sha256
cp "$work/public.bin" "$input/public.der"
sh "$assets/provision.sh" "$input"
curl --noproxy '*' -fsS --connect-timeout 3 --max-time 120 -H 'Content-Type: application/json' --data-binary "@$work/poll.json" "$server/api/enrollment/complete" -o /dev/null || true
rm -f "$work/register.json" "$work/poll.json" "$work/reply.json" "$work/private.pem" "$work/token" "$work/sealed.bin" "$work/signature.bin"
echo 'Configured. Open Kids and log in with the account assigned on the admin page.' > "$work/status.txt"
